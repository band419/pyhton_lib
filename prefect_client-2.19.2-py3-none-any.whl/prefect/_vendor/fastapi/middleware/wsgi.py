from prefect._vendor.starlette.middleware.wsgi import (
    WSGIMiddleware as WSGIMiddleware,
)
