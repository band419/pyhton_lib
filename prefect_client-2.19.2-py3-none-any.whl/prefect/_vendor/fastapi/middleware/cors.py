from prefect._vendor.starlette.middleware.cors import (
    CORSMiddleware as CORSMiddleware,
)
