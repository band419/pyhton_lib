from prefect._vendor.starlette.middleware.gzip import (
    GZipMiddleware as GZipMiddleware,
)
