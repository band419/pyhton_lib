from prefect._vendor.starlette.middleware.trustedhost import (  # noqa
    TrustedHostMiddleware as TrustedHostMiddleware,
)
