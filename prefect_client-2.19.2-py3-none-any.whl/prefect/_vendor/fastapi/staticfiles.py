from prefect._vendor.starlette.staticfiles import StaticFiles as StaticFiles  # noqa
